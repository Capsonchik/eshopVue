<template>
    <footer>
      <div class="container">
        <div class="footer-content">
            <p>Ничосе как могу =) &copy;</p>
        </div>
      </div>
  </footer>
</template>

<style>
.footer-content {
    height: 65px;
    background-color: rgb(202, 194, 194);
    display: flex;
    justify-content: center;
    align-items: center;
}
</style>